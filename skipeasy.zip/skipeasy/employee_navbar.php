<div class="row">
<nav class="navbar navbar-dark navbar-fixed-top" style="background-color: #4682b4;">
       <div class="navbar-header">
         <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu">
          <span class="sr-only"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
         </button>
       </div>
      <div class="collapse navbar-collapse" id="menu"> 
       <ul class="nav navbar-nav">
          <li><a>&ensp;</a></li>
          <li><a href="edit_employee.php" class="btn btn-lg" style="color:white;">Update Profile</a></li>
          <li><a href="#" class="btn btn-lg" style="color:white;">Change Password</a></li>
          <li><a href="#" class="btn btn-lg" style="color:white;">My Jobs</a></li>
          <li><a href="#" class="btn btn-lg" style="color:white;">Update Job Status</a></li>
          <li><a href="#" class="btn btn-lg" style="color:white;">Logout</a></li>
       </ul>
</nav>
</div>
