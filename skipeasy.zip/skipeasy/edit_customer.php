<!doctype html>
<?php 
 include "navbar.php";
 include "dbconfig.php";
 $customer_id=$_GET['customer_id'];
 
?>
<html>
<head>
<meta charset="utf-8">
<title>SkipTrak Software for Skip Hire Business</title>

</head>

<body>
  <form method="post" action="update_customer.php">
      <div class="container-fluid">
      <div class="row">
         <div class="col-md-12">
            <div>&ensp;</div>
            <div>&ensp;</div>
            <div>&ensp;</div>
         </div>
      </div>
        <div class="row">
        <div class="col-md-12" style="margin-top:7%;">
         <form method="post">
           <div class="col-md-2"></div>
           <div class="col-md-8">
              <div class="row">
                  <div class="panel">
                    <div class="panel-primary" style="box-shadow: 5px 5px 5px;">
                      <div class="panel-heading">
                        <h4><center>Personal Detail</center></h4>
                      </div>
                    </div>
                    <div class="panel-body" style="background-color:#e9e9e9;box-shadow: 5px 5px 5px;">
                      <div class="col-md-6">
                      <?php
                      
                      $sql="SELECT customers.name, customers.mobile, customers.address1,customers.address2, customers.city, customers.post_code,customers.phone,customers.email,delivery_address.address1 AS delivery_address1,delivery_address.address2 AS delivery_address2,delivery_address.city AS delivery_city,delivery_address.post_code AS delivery_post_code
FROM customers
LEFT JOIN delivery_address ON customers.id=delivery_address.customer_id
WHERE customers.id='$customer_id' ";
            //echo $sql;
			
			$res=mysqli_query($con,$sql);
            $delivery_row=mysqli_fetch_array($res);
			$rowcount=mysqli_num_rows($res);

                  ?>
                        <label for="name">Full Name</label>
                        <div class="form-group">
                          <input type="text" id="name" name="name" value="<?php echo $delivery_row['name'];?>" class="form-control">
                       </div>
                       <label for="mobile">Mobile</label>
                       <div class="form-group">
                         <input type="text" id="mobile" name="mobile" value="<?php echo $delivery_row['mobile'];?>" class="form-control">
                       </div>
                       <label for="address1">Address Line1</label>
                       <div class="form-group">
                         <input type="text" name="address1" id="address1" value="<?php echo $delivery_row['address1'];?>" class="form-control">
                       </div>
                       <label for="city">City</label>
                       <div class="form-group">
                         <input type="text" name="city" id="city" value="<?php echo $delivery_row['city'];?>" class="form-control">
                      </div> 
                     </div>
                      <div class="col-md-6">
               <label for="phone">Phone</label> 
                  <div class="form-group">
                    <input type="text" id="phone" name="phone" value="<?php echo $delivery_row['phone']?>" class="form-control">
                  </div>
                 <label for="email">Email</label>
                  <div class="form-group">
                    <input type="Email" id="email" name="email" value="<?php echo $delivery_row['email'];?>" class="form-control">
                  </div>
                  <label for="address2">Address Line2</label>
                  <div class="form-group">
                    <input type="text" id="address2" name="address2" value="<?php echo  $delivery_row['address2'];?>" class="form-control">
                  </div>
                   <label for="post_code">Post Code</label>
                  <div class="form-group">
                    <input type="text" id="post_code" name="post_code" value="<?php echo $delivery_row['post_code'];?>" class="form-control">
                  </div>
              </div>
              
              </div>
              </div>
           </div>                                          
                </div>
                <div class="col-md-2"></div>
                </div>
                </div>
                
         
                  <div class="row">
                  <div class="col-md-2"></div>
           <div class="col-md-8" style="padding-left: 0px;padding-right: 0px;">
              <div class="col-md-2"></div>
               <div class="panel">
                    <div class="panel-primary" style="box-shadow: 5px 5px 5px;">
                       <div class="panel-heading"><h4><center>Delivery Address</center></h4></div>
                    </div>
                    <div class="panel-body" style="background-color:#e9e9e9;box-shadow: 5px 5px 5px;">
                      <div class="col-md-12">
                      <div class="pull-right">
<button class="btn btn-success" data-toggle="modal" data-target="#add_new_record_modal">Add New Record</button>
</div><div class="row">
<div class="col-md-12">
<h4>Records:</h4>
<div class="records_content"></div>
</div>
                     <table id="new_customer_table" class="table table-bordered table-hover">
                      <thead>
                        
                        <tr class="btn-primary">
                             <th class="col-md-1">Sr.No</th>
                             <th class="col-md-3"><center>Address Line 1</center></th>
                             <th class="col-md-3"><center>Address Line 2</center></th>
                             <th class="col-md-2"><center>City</center></th>
                             <th class="col-md-1"><center>Post_Code</center></th>
                             <th class="col-md-1"><center>New</center></th>
                             <th class="col-md-1"><center>Remove</center></th>
                        </tr>     
                        </thead>
                       
                        <tbody>
                         <?php 
                              while($delivery_row1=mysqli_fetch_assoc($res))
                              {

                          ?>
                        <tbody>
                            <tr> 
                                <td class="col-md-1">1</td>
                                <td class="col-md-4">
                                  <div class="form-group">
                                     <input type="text" class="form-control" name="del_address1[]" id="delivery_address1" value="<?php echo $delivery_row1['delivery_address1'];?>">
                                  </div>
                                </td>
                                <td class="col-md-4">
                                  <div class="form-group">
                                   <input type="text" name="delivery_address2" id="del_address2[]" class="form-control" value="<?php echo $delivery_row1['delivery_address2'];?>">
                                  </div>
                                </td>
                                <td class="col-md-1">
                                  <div class="form-group">
                                      <input type="text" class="form-control" name="del_city[]" id="delivery_city" value="<?php echo $delivery_row1['delivery_city'];?>">
                                  </div>
                                </td>
                                <td class="col-md-1">
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="del_post_code[]" id="delivery_post_code" value="<?php echo $delivery_row1['delivery_post_code'];?>">
                                  </div>
                                </td>
                                
                            </tr>
                            <?php
                              }
                              ?>
                        </tbody>
                          </table>
                           </div>
                    </div>
		   <div class="col-md-2"></div>									
           <input type="hidden" name="create_new_customer" value="true" />
           <input type="hidden" id="rowcount" name="rowcount" value="<?php echo $rowcount;?>" />
           <input type="hidden" id="customer_id" name="customer_id" value="<?php echo $customer_id;?>" />
                    </div>
           </div>
                 </div>
          </form>
 <!-- Bootstrap Modal - To Add New Record -->
<!-- Modal -->
<div class="modal fade" id="add_new_record_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<h4 class="modal-title" id="myModalLabel">Add New Record</h4>
</div>
<div class="modal-body">
 
<div class="form-group">
<label for="first_name">First Name</label>
<input type="text" id="first_name" placeholder="First Name" class="form-control" />
</div>
 
<div class="form-group">
<label for="last_name">Last Name</label>
<input type="text" id="last_name" placeholder="Last Name" class="form-control" />
</div>
 
<div class="form-group">
<label for="email">Email Address</label>
<input type="text" id="email" placeholder="Email Address" class="form-control" />
</div>
 
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
<button type="button" class="btn btn-primary" onclick="addRecord()">Add Record</button>
</div>
</div>
</div>
</div>
	
</script>
</body>
</html>  
