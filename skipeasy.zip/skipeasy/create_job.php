<!doctype html>
<?php 
include "navbar.php";

?>
1<html>
<head>
<meta charset="utf-8">
<title>SkipTrak Software for Skip Hire Business</title>

</head>

<body>

<section id="main-content">
      <section class="wrapper">
<!-- page start-->
            <div class="row">
                <div class="col-sm-12">
                    <section class="panel">
                          <header class="panel-heading"> Create New Job </header>
                            <div class="panel-body">
                                       <H1> Welcome to Skip Track</H1>
                                       <!-- Code by Ajaj Here -->
                                       
                                                      
                            </div>
                    </section>
                </div>
             </div>
      </section>
   </section>
</body>
</html>