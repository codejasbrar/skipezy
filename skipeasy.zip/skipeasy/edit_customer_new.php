<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Customer Editing Screen</title>
<?php include "navbar.php";
include "dbconfig.php";
?>

<?php
 $customer_id=$_GET['customer_id'];
                      
$sql="SELECT customers.name, customers.mobile, customers.address1,customers.address2, customers.city, customers.post_code,customers.phone,customers.email,delivery_address.address1 AS delivery_address1,delivery_address.address2 AS delivery_address2,delivery_address.city AS delivery_city,delivery_address.post_code AS delivery_post_code
FROM customers
LEFT JOIN delivery_address ON customers.id=delivery_address.customer_id
WHERE customers.id='$customer_id' ";
            //echo $sql;
			
			$res=mysqli_query($con,$sql);
            $customer_data=mysqli_fetch_array($res);
			$rowcount=mysqli_num_rows($res);

                  ?>
</head>

<body>
<div>&nbsp;</div>
<div class="container"><h2>Details of <?php echo '<b>'.$customer_data['name'].'</b>';?></h2></div>
<hr>
<div id="customer_tab" class="container">	
<ul class="nav nav-tabs">
			<li class="active">
        <a  href="#personal_details" data-toggle="tab">Personal Details</a>
			</li>
			<li><a href="#delivery_address" data-toggle="tab">Delivery Addresses</a>
			</li>
			<li><a href="#jobs_done" data-toggle="tab">Jobs Done</a>
			</li>
		</ul>

			<div class="tab-content ">
			  <div class="tab-pane active" id="personal_details">
          <!-- Tab Content Starts -->
           <div class="panel">
                    <div class="panel-primary" style="box-shadow: 5px 5px 5px;">
                      <div class="panel-heading">
                        <h4><center>Personal Detail</center></h4>
                      </div>
                    </div>
                    <div class="panel-body" style="background-color:#e9e9e9;box-shadow: 5px 5px 5px;">
                      <div class="col-md-6">
                      
                        <label for="name">Full Name</label>
                        <div class="form-group">
                          <input type="text" id="name" name="name" value="<?php echo $customer_data['name'];?>" class="form-control">
                       </div>
                       <label for="mobile">Mobile</label>
                       <div class="form-group">
                         <input type="text" id="mobile" name="mobile" value="<?php echo $customer_data['mobile'];?>" class="form-control">
                       </div>
                       <label for="address1">Address Line1</label>
                       <div class="form-group">
                         <input type="text" name="address1" id="address1" value="<?php echo $customer_data['address1'];?>" class="form-control">
                       </div>
                       <label for="city">City</label>
                       <div class="form-group">
                         <input type="text" name="city" id="city" value="<?php echo $customer_data['city'];?>" class="form-control">
                      </div> 
                     </div>
                      <div class="col-md-6">
               <label for="phone">Phone</label> 
                  <div class="form-group">
                    <input type="text" id="phone" name="phone" value="<?php echo $customer_data['phone']?>" class="form-control">
                  </div>
                 <label for="email">Email</label>
                  <div class="form-group">
                    <input type="Email" id="email" name="email" value="<?php echo $customer_data['email'];?>" class="form-control">
                  </div>
                  <label for="address2">Address Line2</label>
                  <div class="form-group">
                    <input type="text" id="address2" name="address2" value="<?php echo  $customer_data['address2'];?>" class="form-control">
                  </div>
                   <label for="post_code">Post Code</label>
                  <div class="form-group">
                    <input type="text" id="post_code" name="post_code" value="<?php echo $customer_data['post_code'];?>" class="form-control">
                  </div>
              </div>
              
              </div>
              <div class="pull-right">
<button class="btn btn-success" data-toggle="modal" data-target="#add_new_record_modal">Update Record</button>
</div>
              </div>
          <!--  Tab Content Ends -->
                </div>
		  <div class="tab-pane" id="delivery_address">
          <!--  Tab Content Starts -->
          <?php include "update_customer_delivery_address.inc.php?customer_id=153";?>
          <!--  Tab Content Ends -->
		  </div>
        <div class="tab-pane" id="jobs_done">
          <h3>add clearfix to tab-content (see the css)</h3>
				</div>
			</div>
  </div>

</body>
</html>