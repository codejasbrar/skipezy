<?php require_once('adminheader.php');?>
<script>
function popupCenter(pageURL, title, w, h) {
    var left = (screen.width / 2)  - (w / 2);
    var top  = (screen.height / 2) - (h / 2);
    var targetWin = window.open(pageURL, title, 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, copyhistory=no, width='+w+', height='+h+', top='+top+', left='+left);
}
</script>
<?php

require_once('dbfunction.php');	

$con = dbconnection();

if(!isset($_SESSION['User']) || empty($_SESSION['User']))

{

	if(true)

	{?>

    	<script type="text/javascript">

			window.location.href='login.php';

        </script>;

    <?php

	}

}

else

{

	$condition = array();

	$condition['id'] = $_REQUEST['id']; 

	$orders = selectWhere($con,'orders',$condition);

	//--------------

	$condition = array();

	$condition['id'] = $orders[0]['customer_id'];

	$customer = selectWhere($con,'customers',$condition);

	//--------

	$condition = array();

	$condition['order_id'] = $orders[0]['id']; 

	$customerPhonedetails = selectWhere($con,'customer_phone_details',$condition);

	//--------

	$result = getAll($con,'phones');

	$phoneBrands = array();

	$phoneModels = array();

	$phoneModelBrand = array();

	$phoneModelBrandName = array();

	if(!empty($result))

	{

		foreach($result as $key=>$value)

		{

			if($value['parent_id'] == 0)

			{

				$phoneBrands[$value['id']] = $value['name'];

			}

			else

			{

				$phoneModels[$value['id']] = $value['name'];

				$phoneModelBrand[$value['id']] = $value['parent_id'];

			}

		}

	}

	$problem = array();

	$status = array();

	$result = getAll($con,'status');

	if(!empty($result))

	{

		foreach($result as $key=>$value)

		{

			if($value['type'] == 'Problem')

			{

				$problem[$value['id']] = $value['name'];

			}

			if($value['type'] == 'Order')

			{

				$status[$value['id']] = $value['name'];

			}

		}

	}

}?>

<div class="form-box" id="login-box" style="margin-top:22px;width: 90%;">

	<div class="header">Thank you for your visit</div>

    <div class="alert alert-success alert-dismissable">

        <i class="fa fa-check"></i>

        <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>

        <b>Success!</b> Your phone details has been added successfully.

    </div>

    <aside class="right-side" style="margin-left: 1%;width: 99%;">                

        <!-- Content Header (Page header) -->

        <section class="content-header">

            <h1>

                Invoice

                <small>#<?php echo strtotime(date('y-m-d H:i:s'));?></small>

            </h1>

        </section>



        <!-- Main content -->

        <section class="content invoice">                    

            <!-- title row -->

            <div class="row">

                <div class="col-xs-12">

                    <h2 class="page-header">

                        <i class="fa fa-globe"></i>Micro Max Communications ltd

                        <small class="pull-right">Date: <?php echo date('d-m-Y');?></small>

                    </h2>                            

                </div><!-- /.col -->

            </div>

            <!-- info row -->

            <div class="row invoice-info">

                <div class="col-sm-4 invoice-col">

                    From

                    <address>

                        <strong>Micro Max Communications Ltd</strong><br>

                        666 Uxbridge Road Hayes ub4 0ry. <br>

                        Phone: 02085611160<br/>

                        Email: info@almasaeedstudio.com

                    </address>

                </div><!-- /.col -->

                <div class="col-sm-4 invoice-col">

                    To

                    <address>

                        <strong><?php echo @$customer[0]['name'];?></strong><br>

                        <?php echo @$customer[0]['address'];?><br>

                        <?php echo @$customer[0]['city'];?>, <?php echo @$customer[0]['state'];?><br>

                        Phone: <?php echo @$customer[0]['phone'];?><br/>

                        Email: <?php echo @$customer[0]['email'];?>

                    </address>

                </div><!-- /.col -->

                <div class="col-sm-4 invoice-col">

                    <b>Invoice #<?php echo strtotime(date('y-m-d H:i:s'));?></b><br/>

                    <br/>

                    <b>Order ID:</b> <?php echo @$orders[0]['serialno'];?><br/>

                    <b>Payment Due:</b><?php echo @date('d-m-Y',strtotime(date('d-m-Y'). '+15 day'));?><br/>

                </div><!-- /.col -->

            </div><!-- /.row -->



            <!-- Table row -->

            <div class="row">

                <div class="col-xs-12 table-responsive">

                    <table class="table table-striped">

                        <thead>

                            <tr>

                                <th>Qty</th>

                                <th>Brand</th>

                                <th>Product</th>

                                <th>Serial #</th>

                                <th>Description</th>

                                <th>Subtotal</th>

                            </tr>                                    

                        </thead>

                        <tbody>

                        	<?php

							if(!empty($customerPhonedetails))

							{

								$i = 1;	

								foreach($customerPhonedetails as $i=>$detail)

								{?>

									<tr>

										<td>1</td>

                                        <td><?php echo @$phoneBrands[$phoneModelBrand[$detail['phone_id']]];?></td>

										<td><?php echo @$phoneModels[$detail['phone_id']];?></td>

										<td><?php echo $detail['imie'];?></td>

										<td><?php echo @$problem[$detail['problem_id']].', '.$detail['customer_remarks'];?></td>

										<td><?php echo number_format($detail['price'],2);?></td>

									</tr>

								<?php

								}

							}?>

                        </tbody>

                    </table>                            

                </div><!-- /.col -->

            </div><!-- /.row -->



            <div class="row">

                <!-- accepted payments column -->

                <div class="col-xs-6">

                    <p class="lead">Payment Methods:</p>

                    <img src="http://www.seychelles.net/isurf/images/VisaMastercardPaypal.jpg" width="150" height="80" alt="Visa"/>

                   <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">

                        Order Status: <?php echo @$status[$orders[0]['status_id']];?>

                    </p>

                </div><!-- /.col -->

                <div class="col-xs-6">

                    <p class="lead">Amount Due on:<?php echo @date('d-m-Y',strtotime(date('d-m-Y'). '+15 day'));?></p>

                    <div class="table-responsive">

                        <table class="table">

                            <tr>

                                <th style="width:50%">Subtotal:</th>

                                <td><?php echo number_format(@$orders[0]['total_price'],2);?></td>

                            </tr>

                            <tr>

                                <th style="width:50%">Paid Amt:</th>

                                <td><?php echo number_format(@$orders[0]['paid_price'],2);?></td>

                            </tr>

                            <tr>

                                <th>Total:</th>

                                <td><?php echo number_format(@$orders[0]['pending_price'],2);?></td>

                            </tr>

                        </table>

                    </div>

                </div><!-- /.col -->

            </div><!-- /.row -->



            <!-- this row will not appear when printing -->

            <div class="row no-print">

                <div class="col-xs-12">

                    <button class="btn btn-default" onclick="popupCenter(bill.php?id=<?php echo  $_REQUEST['id'];?>);"><i class="fa fa-print"></i> <a href="bill.php?id=<?php echo  $_REQUEST['id'];?>" target="_blank" style="width:42px;height:42px;border:0">Create Customer Recipt</a></button>
                     <button class="btn btn-default" onclick="popupCenter(shopbill.php?id=<?php echo  $_REQUEST['id'];?>);"><i class="fa fa-print"></i> <a href="shopbill.php?id=<?php echo  $_REQUEST['id'];?>" target="_blank" style="width:42px;height:42px;border:0">Shop Printable Recipt</a></button>

                </div>

            </div>

        </section><!-- /.content -->

    </aside><!-- /.right-side -->
	<div class="col-xs-3">
    <div class="footer">                    

        <a href="customerphonedetails.php" class="text-center" style="color:#FFF;display: block; margin-bottom: 2px;"><button class="btn bg-olive btn-block">

        	Click here to add more record

      	</button></a></div>
        
	<div class="col-xs-6">

        <a href="logout.php" class="text-center" style="color:#FFF;display: block; margin-bottom: 2px;"><button class="btn bg-olive btn-block">

        	Click here to exit

      	</button></a></div>

    </div>
    

</div>

<?php require_once('adminfooter.php');?>