<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Drivers Change</title>
<?php 
include "dbconfig.php";
include "php_functions.php";
include "dbfunction.php";
ob_start();
?>
<!-- Java Scripti Files -->
 
</head>
<body>
<?php
   						if (ISSET($_POST['select_job_id'])) {
									//print_r($_POST);
									// -------------- add more rows and connect here to database -- all fields
									
									//$col_id=$con->real_escape_string($_POST['selected_col']);
									$order_id=$con->real_escape_string($_POST['select_job_id']);
									$customers_sql="SELECT * FROM order_status"; 
									echo $customers_sql;
									$result=mysqli_query($con,$customers_sql);
						?>
                           
                           
 <div class="modal-dialog">
 <input type="hidden" id="order_id" value="<?php echo $order_id;?>">
 <input type="hidden" id="end_date" value="<?php echo date('Y-m-d');?>">
    <div class="modal-content">
      <div class="panel" style="background-color: #e9e9e9;box-shadow: 5px 5px 5px 5px;">
                    
                     <div class="panel-heading" style="background-color:#EDFB0D;"><center>Update Job Status</center></div>
                    
                     <div class="panel-body">
                     
      <div class="modal-body">
         <div class="col-md-12">
            <div class="col-md-6">
               
               <label class="col-sm-4">Amount</label>
               <div class="form-group col-sm-8">
                  <input type="text" id="total" name="total" class="form-control" value="200.00">
               </div>
                              <label class="col-sm-4">Job Status</label>
                <div class="form-group col-sm-8">
                   <select class="form-control" id="job_status">
                      <?php
                 
                    $payment_sql="SELECT * from order_status";
                  $t_result=mysqli_query($con,$payment_sql);
                  while($payment=mysqli_fetch_assoc($t_result))
                  {
                  ?>
                  
  <option style="padding:10px; background-color:#2977C9; color:#F9F0F1; cursor:pointer;" value="<?php echo $payment['id']; ?>">
     <?php echo $payment['name']; ?>
    </option>
            <?php
            
            }
            ?>
                   </select>
                </div>
               </div>
            
            <div class="col-md-6">
            <div class="col-md-12">
                <label class="col-sm-4">Paid?</label>
               <div class="form-group col-sm-8">
                  <select style="height:30px" name="job_paid" id="job_paid"  class="form-control" style="font-size:13px; cursor:pointer;">
                                <option style="padding:10px; background-color:#2977C9; color:#F9F0F1; cursor:pointer;"value="1" selected>Fully Paid</option>
                              
                               <?php
                 
                    $payment_sql="SELECT * from payment_type order by id ASC";
                  $t_result=mysqli_query($con,$payment_sql);
                  while($payment=mysqli_fetch_assoc($t_result))
                  {
                  ?>
                  
  <option style="padding:10px; background-color:#2977C9; color:#F9F0F1; cursor:pointer;" value="<?php echo $payment['id']; ?>">
     <?php echo $payment['name']; ?>
    </option>
            <?php
            
            }
            ?>
                             </select> 
                   </div>
                    </div>
                   <div class="col-md-12">
                     <div class="col-md-4"><label>Driver</label></div>
                        <div class="col-md-8">
                           <select name="driver" id="driver_id"  class="form-control col-sm-4" style="font-size:13px; cursor:pointer;">
                              
            <?php
                  $payment_sql="SELECT * from employees WHERE job_title = 1 order by id ASC";
                  $t_result=mysqli_query($con,$payment_sql);
                  while($driver_data=mysqli_fetch_assoc($t_result))
                  {
           ?>                  
  <option style="padding:10px; background-color:#2977C9; color:#F9F0F1; cursor:pointer;" value="<?php echo $driver_data['id']; ?>">
     <?php echo $driver_data['name']; ?>
    </option>
            <?php
            }
            ?>
                             </select>
   </div>
                 
    </div>
           
         </div>
            </div>
      
                    
                    </div>
                  </div>
                  
                  
                 <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
        <input type="submit" name="allocate_job" id="modal_button" class="btn btn-primary" value="Update Job Status"/>
        </form>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
                <?php } ?>
 
 <!-- Now allocate job to selected driver -->
       <?php
       if(isset($_POST['selected_payment_status']))
			{
				
				//$id=$_POST['selected_payment_status'];
				$order_id=$con->real_escape_string($_POST['order_id']);
				$payment_status=$con->real_escape_string($_POST['job_paid']);
				$job_status=$con->real_escape_string($_POST['job_status']);
				$amount=$con->real_escape_string($_POST['total']);
				$driver=$con->real_escape_string($_POST['driver_id']);
				//$driver_id=$_POST['driver'];
				//print_r($_POST);
			    
				    
					//$order_id=$ID;
					$sql="UPDATE orders SET total_amount=$amount,status=$job_status WHERE id=$order_id";
					echo $sql;
					
					if (!mysqli_query($con,$sql)) {
			  			
			  			die('UPDATE 3 INTO ORDER_Details -Error: ' . mysqli_error($con));
		  				}	
					
					$sql="UPDATE order_details SET payment_status=$payment_status,driver_id=$driver,amount=$amount WHERE order_id=$order_id";
					echo $sql;
					
					if (!mysqli_query($con,$sql)) {
			  			
			  			die('UPDATE 4 INTO ORDER_Details -Error: ' . mysqli_error($con));
		  				}
					//Use of a Select funtinoc here caled from dbfunction file
					$condition = array();
					$condition['order_id'] = $order_id; 
					$orders = selectWhere($con,'order_details',$condition);
					$source_id = $orders[0]['customer_id'];
										
					// Now reterive job_type and skip_ids
					$condition = array();
					$condition['order_id'] = $order_id; 
					$skips = selectWhere($con,'order_details',$condition);
					
					$skip_id = $skips[0]['skip_id'];
					$exchange_skip_id = $skips[0]['exchange_skip_id'];
					$job_type = $skips[0]['job_type'];
					$quantity = $skips[0]['skips'];
					
					// Now retrieve the stock of this old skip
					$skip_condition = '';
					$skip_condition = array();
					$skip_condition['id'] = $skip_id; 
					$skip_stock = selectWhere($con,'skips',$skip_condition);
					
					$size = $skip_stock[0]['size'];
					$current_stock = $skip_stock[0]['current_stock'];
				
					// Now we need to check if this job is a exchange, job_type=3
					
					if($job_type==3) // Exchange Job
					{
						
						  // Now retrieve the stock of this exchanged skip
						  $skip_condition = '';
						  $skip_condition = array();
						  $skip_condition['id'] = $exchange_skip_id; 
						  $skip_stock = selectWhere($con,'skips',$skip_condition);
						  
						  $size = $skip_stock[0]['size'];
						  $current_stock_of_exchange_skip = $skip_stock[0]['current_stock'];
						  
						  $current_stock=$current_stock+$quantity;
						  $current_stock_of_exchange_skip=$current_stock_of_exchange_skip-$quantity;
						  if($exchange_skip_id!=$skip_id)
						  {
						  // Now simply update stock of old skip
						  $sql="UPDATE skips SET current_stock=$current_stock WHERE id=$skip_id";
						  //echo $sql;
					  
						  if (!mysqli_query($con,$sql)) {
							  
							  die('UPDATE 6 INTO ORDER_Details -Error: ' . mysqli_error($con));
							  }
							  // Now simply update stock of New skip
						  $sql="UPDATE skips SET current_stock=$current_stock_of_exchange_skip WHERE id=$exchange_skip_id";
						  //echo $sql;
					  
						  if (!mysqli_query($con,$sql)) {
							  
							  die('UPDATE 7 INTO ORDER_Details -Error: ' . mysqli_error($con));
							  }
					     //Update skip entry in order_details table
						  }
						 $sql="UPDATE order_details SET skip_id=$exchange_skip_id WHERE order_id=$order_id";
					//echo $sql;
				
					if (!mysqli_query($con,$sql)) {
			  			
			  			die('UPDATE 4 INTO ORDER_Details -Error: ' . mysqli_error($con));
		  				}
						
					}//if
					
					elseif($job_type==1){
						
						
							$current_stock=$current_stock-$quantity;
							// Now simply update stock
							$sql="UPDATE skips SET current_stock=$current_stock WHERE id=$skip_id";
							//echo $sql;
						
							if (!mysqli_query($con,$sql)) {
								
								die('UPDATE 5 INTO ORDER_Details -Error: ' . mysqli_error($con));
								}
								
					
					}//else if this job is a excahnge job
					elseif($job_type==2){
						
						
							$current_stock=$current_stock+$quantity;
							// Now simply update stock
							$sql="UPDATE skips SET current_stock=$current_stock WHERE id=$skip_id";
							//echo $sql;
						
							if (!mysqli_query($con,$sql)) {
								
								die('UPDATE 6 INTO ORDER_Details -Error: ' . mysqli_error($con));
								}
								
					
					}//else if this job is a excahnge job
					
				
								
			?>	
			
            
					
				
			<?php }	?> 


<div class="modal fade"  id="confirmModal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title">Confirmation !</h4>
      </div>
      <div class="modal-body">
        <p style="color:black; background-color:#36EB34; padding:20px; font-size:20px; font-weight:bold;"> Job Status Updated Successfully.</p>
      </div>
      <div class="modal-footer">
        <button type="button" id="closeme" data-dismiss="modal" class="btn btn-success">Close ME</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script type="text/javascript">
$('#modal_button').click(function(){
	var order_id=$('#order_id').val();
	var selected_payment_status='Y';
	var end_date=$('#end_date').val();
	var total=$('#total').val();
	var job_status=$('#job_status').val();
	var job_paid=$('#job_paid').val();
	var driver_id=$('#driver_id').val();
	
	
	var dataString = 'selected_payment_status=' + selected_payment_status+'&order_id=' + order_id+'&job_status=' + job_status+'&end_date=' + end_date+'&total=' + total+'&job_paid=' + job_paid+'&driver_id=' + driver_id;
	alert(dataString);
	var td_id=$('#td_id').val();
	//alert(td_id);
	$.ajax({
		type: "POST",
    url: "update_job.php",
    data: dataString,
    success: function(data) {
		 $('#list_jobs').find('tr#'+1).find('td:eq(12)').html('Demo');
		
		$('#confirmModal').modal('show');
		}
	
	
	});
	
	
  });
  
  $('#closeme').click(function(){
  
 // window.location.reload();
  });
  
 
  
$('#demo').click(function(){
	
	alert("I click checkbox");



});

</script> 
</body>
</html>