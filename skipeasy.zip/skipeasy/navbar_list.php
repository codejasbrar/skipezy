
<link rel="stylesheet" href=" https://bootswatch.com/spacelab/bootstrap.css">
<link rel="stylesheet" href="http://bootswatch.com/spacelab/bootstrap.min.css">

 
<link href='https://fonts.googleapis.com/css?family=Coda+Caption:800|Pacifico|Hind|Anton|Chewy|Bangers|Montserrat:400,700' rel='stylesheet' type='text/css'>
<?php include "navbar_content.inc.php";?>