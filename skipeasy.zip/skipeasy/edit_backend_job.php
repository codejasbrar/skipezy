<?php 
   if(isset($_GET['cid']))
   {
   	  $cid=$_GET['cid'];
   }
   if(isset($_POST['btn']))
   {
   	  
   }

?>