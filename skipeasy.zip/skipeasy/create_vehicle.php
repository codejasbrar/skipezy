<?php 
   include "dbconfig.php";
   include "php_functions.php";
   include "dbfunction.php";
   ob_start();
   
   if(isset($_POST['reg_plate']))
      
   {
      print_r($_POST);
         $condition=$_POST;
         $res = insert($con,"vehicles",$condition,true,true);
         if($res)
         {
            echo 'Vehicles Detail Create Successfully';
         }
         else
         {
            echo 'Vehicles Detail Not Created Please Try Again';
         }
   }
                               
?> 