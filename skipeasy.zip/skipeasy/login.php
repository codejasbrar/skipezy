<?php
include "dbconfig.php" ;
  ob_start();
   session_start();
  $uid=$_POST['email'];
$pw=$_POST['password'];
//echo $uid;
//echo $pw;
  if($uid=='admin' && $pw=='53460')
      {
         header("location:index.php"); 
      exit;
      }
    
$tbl_name1="users";
$sql="SELECT * FROM $tbl_name1 WHERE email ='".$uid."' AND password = '".$pw."'";
echo $sql;
//exit;

if (!mysqli_query($con,$sql)) 
              {   
                
                die('SELECT SQL SAID -Error : ' . mysqli_error($con));
              }
$res= mysqli_query($con,$sql);
$user= mysqli_fetch_assoc($res);
echo $users=mysqli_num_rows($res);
//exit;
if(mysqli_num_rows($res) > 0)
{
//  echo "fdsfd";
  session_start();
  echo $user['id'];
  $_SESSION['sid']=session_id();
  $_SESSION['id']=$user['id'];
  $_SESSION['name']=$user['name'];
  $id=$user['id'];
  
    if($uid=='admin'&$pw=='admin')
      {
      header("Location: rota.php"); 
      }
    else
      {
      	   $_SESSION['name']=$uid;
      	   $e_id=$_SESSION['id'];
		   
           header('Location:employee_profile.php');
      }
}
else
{
  header("location:re_login.html");
}
                  

?>