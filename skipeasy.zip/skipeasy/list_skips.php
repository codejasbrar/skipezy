
<meta charset="utf-8">

<title>List of Skips</title>
<!doctype html>

<html>

<head>
  
<?php

include "dbconfig.php";

//include "css_header.php";
include "navbar_list.php";
 include ("dynamic_table.php");
//Get the order data for this order.

$sql="SELECT * FROM skips order by size ASC";

$res=mysqli_query($con,$sql);

//echo $sql;

?>
 </head>

<body style="font-family:Montserrat; font-size:13px;">

<div class="row">
     
                 <div class="panel-heading"><h4><center>Skips Stock Report</center></h4></div>
               
   </div>
  <div class="row">
      <div class="col-md-12">
        <table  style="font-family:Montserrat; font-size:18px;" id="skips" class="table table-striped table-bordered table-hover" cellspacing="0">

        <thead>

            <tr class="btn-primary">

                           <th>Skip Name</th>
                           <th></th>
                           <th>On The Road</th>
                           <th>Jobs Done</th>
                         
            </tr>

        </thead>

        <tfoot>

            <tr class="btn-primary">
                           <th>Skip Name</th>
                           <th></th>
                           <th>On The Road</th>
                          <th>Jobs Done</th>

                           
            </tr>

        </tfoot>

        <tbody >

        <?php

                while($skip=mysqli_fetch_assoc($res))

                  {             
  ?>               
                              <td><?php echo $skip['size'];?></td>
                                 <td><?php 
								 $current_stock=$skip['current_stock'];
								 if($current_stock<5)
								 {
							
							   // echo "<p style='background-color:#E81013; color:#F4EEEE; font-size:20px;'>Only $current_stock left.</p>";
								 }else{
									
								 }
							?>  
                            </td>
                             <td><?php echo $skip['owned']-$current_stock;?></td>
                             <?php 
					$sql="SELECT COUNT(*) as count FROM order_details WHERE skip_id=".$skip['id'];
				    if (!mysqli_query($con,$sql)) 
					  { 	
						  echo $sql;
						  die('SELECT SQL 2 SAID -Error : ' . mysqli_error($con));
					  }//if (!mysqli
					  $result=mysqli_query($con,$sql);
					  $skip_count=mysqli_fetch_assoc($result);
					  $jobs=$skip_count['count'];
							 ?>
                             <td> <a class="btn btn-primary btn-lg" href="jobs_by_skip.php?id=<?php echo $skip['id'];?>"><span class="badge" style="padding:10px;"><?php echo $jobs;?> Jobs - </span> See Deatils</td>
                          </tr>
			      <?php  } ?>

            

            </tbody>

    </table>

    </div>

    </div>
</div>
    </div>
<div class="modal" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div id="order_detail" class="modal-content">
    
    </div>
  </div>
</div>
<script type="text/javascript">

  $(document).ready(function() {
    $('#skips').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copyHtml5',
            'excelHtml5',
            'csvHtml5',
            'pdfHtml5',
			'print'
			        ]
    } );
} );

</script>


</body>
</html>