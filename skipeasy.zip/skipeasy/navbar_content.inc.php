<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
 
<nav class="navbar navbar-inverse navbar-fixed-top yellow-bacground" style="margin-left:5px; margin-top:5px;">
  <div class="navbar-header">
  
    <img style="background-color:white;" src="images/logo.png" width="90" height="70">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
  </div>
  <div class="navbar-collapse collapse">
    <ul class="nav navbar-nav">
            <li class="dropdown">
               <a style="color:white;" class="dropdown-toggle btn-lg" data-toggle="dropdown" href="#">Jobs</a>
                <ul class="dropdown-menu">
                	<li><a href="list_job.php">List of All Jobs</a></li>
                     <li><a  href="new_order.php">Add New Job</a></li>
                    <li><a href="list_job.php">Edit Job</a></li>
                    <li><a href="allocate_Job.php">Allocate Job</a></li>
                    <li><a href="update_job_status.php">Update Job Status</a></li>
                    
                </ul>
            </li>
            <li class="dropdown"><a style="color:white;" href="#" class="dropdown-toggle btn btn-lg" data-toggle="dropdown">Customers</a>
              <ul class="dropdown-menu">
                    <li><a href="new_customer.php">Add New Customer</a></li>
                    <li><a href="#">Edit Customer</a></li>
                    <li><a href="customer_details.php">Full Customer Account</a></li>
                    <li><a href="#">Delete Customer</a></li>
                    <li><a href="list_customer.php">List of All Customers</a></li>
                </ul>
            </li>
         
            <li class="dropdown"><a style="color:white;" href="#" class="dropdown-toggle btn btn-lg" data-toggle="dropdown">Vehicles</a>
              <ul class="dropdown-menu">
                    <li><a href="new_skip.php">Add New Skip</a></li>
                    <li><a href="list_skips.php">Skip Stock Report</a></li>
                    <li><a href="new_vehicle.php">Add New Vehicle</a></li>
                    <li><a href="list_vehicles.php">List of All Vehicles</a></li>
                </ul>
            </li>
            <li class="dropdown"><a style="color:white;" href="#" class="dropdown-toggle btn btn-lg" data-toggle="dropdown">Reminders</a>
            <ul class="dropdown-menu">
                    <li><a href="send_reminder.php">Send a New Reminder</a></li>
                    <li><a href="#">Auto Reminder</a></li>
                    <li><a href="#">Setup Reminders</a></li>
                    
                </ul>
            </li>
            <li class="dropdown"><a style="color:white;" href="#" class="dropdown-toggle btn btn-lg" data-toggle="dropdown">Payments</a>
              <ul class="dropdown-menu">
                    <li><a href="payment_recieved.php">Customer Payement</a></li>
                    <li><a href="list_invoice.php">New Expense</a></li>
                    
                    <li><a href="#">Print Statement</a></li>
                    
                </ul>
            </li>
            
            <li class="dropdown"><a style="color:white;" href="#" class="dropdown-toggle btn btn-lg" data-toggle="dropdown">Invoices</a>
              <ul class="dropdown-menu">
                    <li><a href="new_invoice.php">New Invoice</a></li>
                    <li><a href="list_invoice.php">List of Invoices</a></li>
                    <li><a href="#">Edit Invoice</a></li>
                    <li><a href="#">Print Statement</a></li>
                    
                </ul>
      
            <li class="dropdown"><a style="color:white;" href="#" class="dropdown-toggle btn btn-lg" data-toggle="dropdown">Waybridge</a>
              <ul class="dropdown-menu">
                    <li><a href="artic.php">Create New Job</a></li>
                    <li><a href="list_waybridge.php">See Enteries</a></li>
                    
                </ul>
            </li>
           
            
          
          <li  class="navbar-right dropdown"><a style="color:white;" href="#" data-toggle="dropdown"><span class="glyphicon glyphicon-user">Admin</a>
 <ul class="dropdown-menu">
  <li><a href="new_user.php">Add New User</a></li>
                    <li><a href="#">Search User</a></li>
                    <li><a href="#">Edit User</a></li>
                    <li><a href="#">Delete User</a></li>
                    <li><a href="list_user.php">List of All Users</a></li>
                     <li ><a href="new_user.php">Change Password</a></li>
                    <li><a href="new_group.php">Request New Password</a></li>
                    <li><a href="new_job_title.php">Logout</a></li>
                    
                </ul>
            </li>
            
            
  
  </div>
</nav>
<br>

<div class="col-md-12" style="margin-top:50px;box-shadow: 5px 5px 5px; padding:10px; background-color:#F3ECED;">
<a href="list_job.php" class="btn btn-primary btn-sm">Live Jobs List</a>
 <a href="new_order.php" class="btn btn-primary btn-sm">Add New Job</a>
 <a href="list_skips.php" class="btn btn-primary btn-sm">See Stock Report</a>
 <a href="list_job.php" class="btn btn-primary btn-sm pull-right">Clear Filter</a>
 <a href="artic.php" class="btn btn-sm btn-primary">New Waybridge Entry</a>
 <a href="list_waybridge.php" class="btn btn-sm btn-primary">See Waybridge List</a>
 <a href="new_invoice.php" class="btn btn-sm btn-primary">New Invoice</a>
 <a href="list_invoice.php" class="btn btn-sm btn-primary">List of Invoices</a>
</div>
