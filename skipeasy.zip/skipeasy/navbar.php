
<link rel="stylesheet" href=" https://bootswatch.com/spacelab/bootstrap.css">
<link rel="stylesheet" href="http://bootswatch.com/spacelab/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link href='https://fonts.googleapis.com/css?family=Coda+Caption:800|Pacifico|Hind|Anton|Chewy|Bangers|Montserrat:400,700' rel='stylesheet' type='text/css'>

<?php include "navbar_content.inc.php";?>
