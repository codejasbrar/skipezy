<?php
include "dbconfig.php";
        
           
        		$customer_id=$_POST['customer_id'];
				$rowcount=$_POST['rowcount'];
                $name=$_POST['name'];
                $mobile=$_POST['mobile'];
                $address1=$_POST['address1'];
                $city=$_POST['city'];
                $phone=$_POST['phone'];
                $email=$_POST['email'];
                $address2=$_POST['address2'];
                $post_code=$_POST['post_code'];
                $delivery_address1=$_POST['delivery_address1'];
                $delivery_address2=$_POST['delivery_address2'];
                $delivery_city=$_POST['delivery_city'];
                $delivery_post_code=$_POST['delivery_post_code'];
                $update_customer_sql="UPDATE customers,delivery_address SET customers.name='$name',customers.mobile='$mobile', customers.city='$city', customers.phone='$phone',customers.email='$email',customers.address1='$address1',customers.address2='$address2',customers.post_code='$post_code',delivery_address.address1='$delivery_address1',delivery_address.address2='$delivery_address2',delivery_address.city='$delivery_city',delivery_address.post_code='$delivery_post_code' WHERE customers.id=delivery_address.customer_id and customers.id='$customer_id'";
				//echo $update_customer_sql;
				//$update=mysqli_query($con,$update_customer_sql);
                 $count = count($_POST['delivery_address1']);
				 $i=0;
				 print_r($_POST);
				 exit;
           		// Now save the delivery address of customer
				for ($i = 0; $i < $count; $i++) {
					$address1 = $con->real_escape_string($_POST['delivery_address1'][$i]);
					$address2 = $con->real_escape_string($_POST['delivery_address2'][$i]);
					$city = $con->real_escape_string($_POST['delivery_city'][$i]);
					$post_code = $con->real_escape_string($_POST['delivery_post_code'][$i]);
				
				$update_eelivery_address_sql="UPDATE delivery_address SET
				address1='$address1';
				address2='$address2';
				city='$city';
				post_code='$post_code';
				
				WHERE customer_id=$customer_id";
				echo $update_eelivery_address_sql;
				}
            
?>